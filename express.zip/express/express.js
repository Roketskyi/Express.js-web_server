const express = require('express');
const app = express();
const port = 3000;

const path = require('path');
const fs = require('fs');


app.use(express.static(path.join(__dirname, '/html/site')));

app.get('/', (req, res) => {
    const htmlFilePath = path.join(__dirname, '/html/site', 'index.html');

    fs.readFile(htmlFilePath, 'utf8', (err, data) => {
        if (err) return next(err);

        res.send(data);
    });
});

app.get('/about', (req, res) => {
    const htmlFilePath = path.join(__dirname, '/html/site', 'about.html');

    fs.readFile(htmlFilePath, 'utf8', (err, data) => {
        if (err) return next(err);

        res.send(data);
    });
});

app.use((error, req, res) => {
    res.status(error.status || 500);
    res.sendFile(path.join(__dirname, 'error.html'));
});

app.listen(port, () => {
    console.log(`Веб-сервер був запущений на порту ${port}`);
});
